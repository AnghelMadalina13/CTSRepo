package JUnit;

import static org.junit.Assert.*;
import junit.framework.TestCase;

import org.junit.Test;

import flyweight.Materie;

public class TestMaterie extends TestCase{

	Materie materie=new Materie();
	
	@Test
	public void testPondereCurs() {
		materie.setCurs(70);
		assertEquals(70,materie.getCurs());
	}

	@Test
	public void testPondereSeminar(){
		materie.setSeminar(30);
		assertEquals(30,materie.getSeminar());
	}
	@Test
	public void testDenumireMaterie(){
		materie.setDenumire("CTS");
		assertSame("CTS",materie.getDenumire());
	}
	@Test
	public boolean testCorectitudine(){
	    materie.setCurs(60);
		materie.setSeminar(40);
		int cond1=materie.getCurs();
		int cond2=materie.getSeminar();
		if(cond1 > cond2)
			return true;
		else
			return false;
	}
	@Test
	public void testDiferenta(){
		materie.setCurs(60);
		materie.setSeminar(40);
		int rez=materie.getCurs()-materie.getSeminar();
		assertEquals(20,rez);
	}
	@Test
	public void testMarireNota(){
		materie.setCurs(4);
		materie.setSeminar(4);
		int rez=materie.getCurs()+materie.getSeminar();
		if(rez>=8)
			rez=rez+1;
		assertEquals(9,rez);
		
	}
	@Test 
	public boolean testNepromovat(){
		materie.setCurs(3);
		materie.setSeminar(1);
		int rez=materie.getCurs()+materie.getSeminar();
		boolean cond1=true;
		if(rez<5)
			return cond1;
		return cond1;
	}
}
