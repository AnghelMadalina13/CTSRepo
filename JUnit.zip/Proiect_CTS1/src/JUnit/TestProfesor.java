package JUnit;

import static org.junit.Assert.*;

import java.util.List;

import junit.framework.TestCase;

import org.junit.Test;

import composite.Profesor;

public class TestProfesor extends TestCase{

	Profesor prof=new Profesor();
	
	@Test
	public void testNumeProfesor() {
		try{
			prof.setNume("Catalin Boja");
			assertEquals("Catalin Boja",prof.getNume());
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	@Test
	public void testDepartamentProfesor(){
		try{
			prof.setDepartament("Informatica si Cibernetica Economica");
			assertEquals("Informatica si Cibernetica Economica",prof.getDepartament());
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	@Test
	public void testSalariuProfesor(){
		try{
			prof.setSalariu(3000);
			assertEquals(3000,prof.getSalariu());
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public void testSalariuAnualProfesor(){
		prof.setSalariu(3500);
		assertEquals(42000,prof.salariuAnual());
	}
	public void testSalariuSaptamanal(){
		prof.setSalariu(3500);
		assertEquals(875,prof.salariuSaptamanal());
	}
	public void testImpozitVenit(){
		prof.setSalariu(3000);
		assertEquals(480,prof.impozitVenit());
	}
}
