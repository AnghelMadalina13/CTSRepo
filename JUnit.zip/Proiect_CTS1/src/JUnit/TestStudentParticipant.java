package JUnit;

import static org.junit.Assert.*;
import junit.framework.TestCase;
import observer.StudentParticipant;

import org.junit.Test;

public class TestStudentParticipant extends TestCase{

	StudentParticipant sp=new StudentParticipant("Daniela");
	
	@Test
	public void testNume() {
		assertEquals("Daniela",sp.getNume());
	}

}
