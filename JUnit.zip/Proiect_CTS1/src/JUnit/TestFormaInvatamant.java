package JUnit;

import static org.junit.Assert.*;
import junit.framework.TestCase;
import java.lang.String;

import org.junit.Test;

import exceptions.NumeIncorectException;
import adapter.FormaInvatamant;

public class TestFormaInvatamant extends TestCase{

	public TestFormaInvatamant(String nume){
		super(nume);
	}
	
	@Test
	public void testNumeCorect() {
		try{
			FormaInvatamant fi=new FormaInvatamant("buget");
			assertEquals("buget",fi.getNume());
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	@Test
	public void testNumeIncorect(java.lang.String mesaj){
		try{
		FormaInvatamant fi=new FormaInvatamant();
		fi.setNume("ab");
		fail("Metoda trebuie sa arunce exceptie");
		}catch(NumeIncorectException e){
			e.printStackTrace();
		}
	}

}
