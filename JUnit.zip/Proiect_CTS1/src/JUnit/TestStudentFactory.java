package JUnit;

import static org.junit.Assert.*;
import junit.framework.TestResult;

import org.junit.Test;

import factory.Student;

public class TestStudentFactory implements junit.framework.Test {

	Student student=new Student();
	
	@Test
	public void testActivitate() {
		assertEquals("participa la cursuri",student.activitate());
	}

	@Override
	public int countTestCases() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void run(TestResult arg0) {
		// TODO Auto-generated method stub
		
	}

}
