package JUnit;

import junit.framework.TestSuite;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
@RunWith(Suite.class)
@SuiteClasses({
	TestCurs.class,TestFacultate.class,TestFormaInvatamant.class,
	TestMaterie.class,TestProfesor.class,TestStudentFacade.class,
	TestStudentFactory.class,TestStudentFacultate.class,
	TestStudentParticipant.class,TestStudentTaxa.class,
})
public class AllTestSuite {

public static TestSuite testSuiteMethod(){
	TestSuite test=new TestSuite();
	
	test.addTestSuite(TestCurs.class);
	test.addTest(new TestFacultate());
	test.addTestSuite(TestFormaInvatamant.class);
	test.addTestSuite(TestMaterie.class);
	test.addTestSuite(TestProfesor.class);
	test.addTestSuite(TestStudentFacade.class);
	test.addTest(new TestStudentFactory());
	test.addTestSuite(TestStudentFacultate.class);
	test.addTestSuite(TestStudentParticipant.class);
	test.addTestSuite(TestStudentTaxa.class);
	
	return test;
	
}
}
