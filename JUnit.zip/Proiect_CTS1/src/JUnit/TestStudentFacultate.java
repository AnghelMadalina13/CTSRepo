package JUnit;

import static org.junit.Assert.*;
import junit.framework.TestCase;

import org.junit.Test;

import builder.StudentFacultate;

public class TestStudentFacultate extends TestCase{

	
	StudentFacultate student=new StudentFacultate();
	public TestStudentFacultate(String nume){
		super(nume);
	}
	
	@Test
	public void testNumeStudent() {
		try{
			student.setNume("Alexandru Andreea");
			assertEquals("Alexandru Andreea",student.getNume());
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	@Test
	public void testVarstaStudent(){
		try{
			student.setVarsta(21);
			assertEquals(21,student.getVarsta());
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public void testSpecializareStudent(){
		try{
		student.setSpecializare("Informatica Economica");
		assertEquals("Informatica Economica",student.getSpecializare());
	}catch(Exception e){
		e.printStackTrace();
	}
	}

}
