package JUnit;

import static org.junit.Assert.*;
import junit.framework.TestCase;

import org.junit.Test;

import facade.Curs;

public class TestCurs extends TestCase{

	Curs curs=new Curs("CTS");
	
	@Test
	public void testDenumireCurs() {
		assertSame("CTS",curs.getDenumire());
	}

}
