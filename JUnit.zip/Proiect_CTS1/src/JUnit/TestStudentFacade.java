package JUnit;

import static org.junit.Assert.*;
import junit.framework.TestCase;

import org.junit.Test;

import facade.Student;

public class TestStudentFacade extends TestCase{
	
	Student s=new Student("Anghel Mihaela","2931225231245");

	@Test
	public void testNume() {
		assertEquals("Anghel Mihaela",s.getNume());
	}
	@Test
	public void testSex(){
		assertEquals("F",s.getSex());
	}

}
