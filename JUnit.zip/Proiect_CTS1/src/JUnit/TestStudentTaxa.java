package JUnit;

import static org.junit.Assert.*;
import interfete.ModalitatePlata;
import junit.framework.TestCase;

import org.junit.Test;

import exceptions.NumeIncorectException;
import strategy.PlataCash;
import strategy.PlataCont;
import strategy.StudentTaxa;

public class TestStudentTaxa extends TestCase{

	StudentTaxa studTaxa=new StudentTaxa();
	
	@Test
	public void testNumeCorect() {
		try {
			studTaxa.setNume("Marin Cristina");
		} catch (NumeIncorectException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertEquals("Marin Cristina",studTaxa.getNume());
	}
	public void testModalitateCash(){
		ModalitatePlata modPlata=new PlataCash();
		try{
			studTaxa.setModalitate(modPlata);
			assertEquals(modPlata,studTaxa.getModalitate());
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	@Test
	public void testModalitateCont(){
		ModalitatePlata modPlata=new PlataCont();
		try{
			studTaxa.setModalitate(modPlata);
			assertEquals(modPlata,studTaxa.getModalitate());
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
