package JUnit;

import static org.junit.Assert.*;
import junit.framework.TestResult;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import singleton.Facultate;

public class TestFacultate implements junit.framework.Test {

	private Facultate instanta;
	
	@Before
	public void initializare(){
		try{
			instanta.getInstanta();
		}catch(Exception e){
			
		}
	}
	@Before
	public void setUp(){
		Facultate.getInstanta().setDenumire("Ase");
		Facultate.getInstanta().setAdresa("Bucuresti");
	}
	
	@Test
	public void testDenumireFacultate() {
		try{
			Facultate.getInstanta().setDenumire("Ase");
			assertEquals("Ase",Facultate.getInstanta().getDenumire());
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	@Test
	public void testAdresaFacultate(){
		try{
			Facultate.getInstanta().setAdresa("Bucuresti");
			assertEquals("Bucuresti",Facultate.getInstanta().getAdresa());
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	@Test
	public void testInstanta(){
		Facultate instantaUnica=null;
		try{
			instantaUnica=Facultate.getInstanta();
		}catch(Exception e){
			assertNotEquals(instantaUnica,null);
			assertEquals(instantaUnica.getDenumire(),"Ase");
			assertEquals(instantaUnica.getAdresa(),"Bucuresti");
		}
	}
	@After
	public void destroy(){
		instanta=null;
	}
	@Override
	public int countTestCases() {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public void run(TestResult arg0) {
		// TODO Auto-generated method stub
		
	}

}
